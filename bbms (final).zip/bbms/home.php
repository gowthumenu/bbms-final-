<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>web page</title>
    <link rel="stylesheet" href="C:\Users\vlal1\OneDrive\Desktop\html\v.css">

</head>
<body>
    <header>
        <h1>BLOOD LINK</h1>
        
    </header>
    <nav> 
        <a href="#1">Home</a>
        <a href="#3">Courses</a>
        <a href="review form.html">Reviews</a>
        <a href="admin.php">login/signUp</a>
        <a class="veeresh" href="portfolio.html" target="new tab">About</a>
    </nav>
    <main>
        <section class="quote">
            <h4 id="1">DONATE BLOOD,SAVE LIFE!</h4> <h2>Donate your blood and Inspire others to donate! </h2>
           <button class="button" onclick="location.href='Appointment.html'">Get Appointment</button>
        </section>
        <section>
            <h2 id="3">Donation process</h2>
            <iframe width="560" height="315" src="https://www.youtube.com/embed/YHxdhI5ZrHc?si=wpMqLeefv2ilKgt2" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            <iframe width="560" height="315" src="bd.mp4" autoplay title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

          <!--  <div class="card" style="width: 18rem;">
                <img src="bd.jpg" style="width: 18rem;" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Card title</h5>
                  <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                  <a href="#" class="btn btn-primary">Go somewhere</a>
                </div>
              </div>-->>
        </section>
        <section>
            <h2 id="2">Reviews</h2>
            <iframe width="35%" height="35%" src="https://www.youtube.com/embed/61ppyY5rUB0?si=71CYEGYZCy_x3Gdo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            <iframe width="35%" height="35%" src="https://www.youtube.com/embed/61ppyY5rUB0?si=71CYEGYZCy_x3Gdo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </section>
        <section class="v">
            <h2>Our Volunteer's</h2>
            <div>
            <img class="img" src="C:\Users\vlal1\Downloads\IMG_20240216_235853.jpg" alt="" width="35%" height="35%">
            <a href="portfolio.html"><h4> V E E R E S H</h4></a></div>
            <div>
            <img class="img" src="C:\Users\vlal1\OneDrive\Documents\gowthu.jpg" alt="" width="35%" height="35%">
            <a href="portfolio.html"><h4> G O W T H A M I</h4></a></div>
            <div>
                <img class="img" src="C:\Users\vlal1\OneDrive\Documents\NANDHU1.jpg" alt="" width="35%" height="35%">
                <a href="portfolio.html"><h4> N A N D H U</h4></a></div>
        </section>

    </main>
    <footer>
        <a href="#">FAQ</a>
        <a href="#">Contact US</a>
        <a href="#">Terms of Use</a>
        <a href="#">Privacy Policy</a>
        <a href="#">&copy; 2023 | VEERESH</a>

    </footer>
</body>
</html>