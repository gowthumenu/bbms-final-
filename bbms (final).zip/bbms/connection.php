<?php
$db=new PDO('mysql:host=localhost;port=3307;dbname=bbms','root','');
?>
